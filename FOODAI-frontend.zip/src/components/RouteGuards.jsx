import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

// Blocks access unless a user is logged in (client-side check only — the
// real enforcement is the backend's verifyToken on each request; this just
// avoids flashing protected UI before the first API 401 sends you back).
export function ProtectedRoute({ children }) {
  const { isAuthenticated } = useAuth();
  const location = useLocation();

  if (!isAuthenticated) {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }
  return children;
}

// Blocks access unless the logged-in user has role === "chef"
// (mirrors the backend's verifyAdmin middleware, which — despite the name —
// checks for role "chef", see src/middlewares/auth.middleware.js).
export function ChefRoute({ children }) {
  const { isAuthenticated, isChef } = useAuth();
  const location = useLocation();

  if (!isAuthenticated) {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }
  if (!isChef) {
    return <Navigate to="/home" replace />;
  }
  return children;
}
