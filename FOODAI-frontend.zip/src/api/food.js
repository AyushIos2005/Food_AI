import client from "./client";

// Maps to backend/src/routes/food.route.js -> mounted at /api/food
// Chef-only (admin) endpoints
export const uploadFood = (formData) =>
  client
    .post("/food/upload", formData, {
      headers: { "Content-Type": "multipart/form-data" },
    })
    .then((r) => r.data);
// formData fields: foodImage (file), foodName, ingredients, precautions, description

export const deleteFood = (id) =>
  client.delete(`/food/deletefood/${id}`).then((r) => r.data);

export const getFoodAdmin = () => client.get("/food/get").then((r) => r.data);

// Any logged-in user/chef can browse all dishes
export const getAllFood = () => client.get("/food/get-all").then((r) => r.data);
