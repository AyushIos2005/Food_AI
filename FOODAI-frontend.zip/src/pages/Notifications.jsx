import { Heart, MessageCircle, UserPlus } from "lucide-react";
import { EmptyState } from "../components/States";

const sample = [
  { icon: MessageCircle, text: "Someone commented on your post", time: "2h ago" },
  { icon: Heart, text: "New comment on your post", time: "5h ago" },
  { icon: UserPlus, text: "Someone liked your blog", time: "1d ago" },
];

export default function Notifications() {
  return (
    <div className="max-w-xl space-y-2">
      <p className="text-[13px] text-ink-soft mb-4">
        Live notifications will appear here once the backend exposes an endpoint.
      </p>
      {sample.length === 0 ? (
        <EmptyState title="You're all caught up" description="No new activity yet." />
      ) : (
        sample.map((n, i) => (
          <div key={i} className="card flex items-center gap-3 p-4">
            <div className="w-11 h-11 rounded-full bg-orange-50 flex items-center justify-center text-orange-500 shrink-0">
              <n.icon size={18} />
            </div>
            <div className="min-w-0">
              <p className="text-[14px] text-ink">{n.text}</p>
              <p className="text-[11px] text-ink-soft/50">{n.time}</p>
            </div>
          </div>
        ))
      )}
    </div>
  );
}
