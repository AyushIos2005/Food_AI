import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Sparkles } from "lucide-react";
import { getGeneratedRecipes, getRecreatedFoods } from "../api/ai";
import { AiRecipeCard } from "../components/BlogCard";
import { EmptyState, LoadingState } from "../components/States";

const RECIPE_KEY = "foodai_last_recipe";

export default function AiHub() {
  const [recipes, setRecipes] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    Promise.allSettled([getGeneratedRecipes(), getRecreatedFoods()])
      .then((results) => {
        const list = [];
        results.forEach((r) => {
          if (r.status === "fulfilled") {
            const payload = r.value?.data || r.value?.recipes || r.value;
            if (Array.isArray(payload)) list.push(...payload);
            else if (payload?.recipe) list.push(payload.recipe);
          }
        });
        setRecipes(list);
      })
      .finally(() => setLoading(false));
  }, []);

  const openRecipe = (recipe) => {
    sessionStorage.setItem(RECIPE_KEY, JSON.stringify(recipe));
    navigate("/ai/result");
  };

  return (
    <div>
      <div className="rounded-[28px] bg-gradient-to-br from-orange-500 to-orange-700 text-white p-6 sm:p-8 mb-8">
        <p className="text-[12px] tracking-[0.2em] text-white/70">AI KITCHEN</p>
        <h2 className="font-display text-3xl sm:text-4xl mt-2">Cook from what you already have</h2>
        <p className="text-white/80 mt-2 max-w-lg">
          Tell FOODAI your ingredients, servings, and any medical notes. Get a complete recipe in seconds.
        </p>
        <button onClick={() => navigate("/ai/create")} className="mt-6 bg-white text-orange-700 font-semibold rounded-2xl px-5 py-3 flex items-center gap-2">
          <Sparkles size={16} /> Generate Recipe
        </button>
      </div>

      <h3 className="font-display text-2xl mb-4">Your generated recipes</h3>
      {loading ? (
        <LoadingState label="Loading AI recipes..." />
      ) : recipes.length === 0 ? (
        <EmptyState
          title="No AI recipes yet"
          description="Generate your first protein-smart recipe."
          action={<button onClick={() => navigate("/ai/create")} className="btn-primary mt-3">Create recipe</button>}
        />
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {recipes.map((r, i) => (
            <AiRecipeCard key={r._id || i} recipe={r.recipe || r} onOpen={() => openRecipe(r.recipe || r)} />
          ))}
        </div>
      )}
    </div>
  );
}
